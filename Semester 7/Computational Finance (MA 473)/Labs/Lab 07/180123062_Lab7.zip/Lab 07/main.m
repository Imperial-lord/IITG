% Crank Nicolson
mt(0.5);

% FTCS
figure(2);
mt(0);

% BTCS
figure(3);
mt(1);